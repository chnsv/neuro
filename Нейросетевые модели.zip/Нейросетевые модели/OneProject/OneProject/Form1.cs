﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Reflection.Emit;
using OneProject.NeuroNet;

namespace OneProject
{
    public partial class Form1 : Form
    {
        private double[] _inputPixels = new double[15];
        private NetWork net = new NetWork(NetworkMode.Recogn);

        public Form1()
        {
            InitializeComponent();
        }

        private void changeButton(Button b, int ind)
        {
            if (b.BackColor == Color.Black)
            {
                b.BackColor = Color.White;
                _inputPixels[ind] = 0d;
            }
            else if (b.BackColor == Color.White)
            {
                b.BackColor = Color.Black;
                _inputPixels[ind] = 1d;
            }
        }

        private void SaveTrain(decimal vale, double[] input)
        {
            string pathDir;
            string fileNameTrain;
            pathDir = AppDomain.CurrentDomain.BaseDirectory;
            fileNameTrain = pathDir + "train.txt";
            string data = vale.ToString();
            foreach (int i in input)
            {
                data += " " + i.ToString();
            }
            data += "\n";
            File.AppendAllText(fileNameTrain, data);
        }

        private void SaveTest(decimal vale, double[] input)
        {
            string pathDir;
            string fileNameTrain;
            pathDir = AppDomain.CurrentDomain.BaseDirectory;
            fileNameTrain = pathDir + "test.txt";
            string data = vale.ToString();
            foreach (int i in input)
            {
                data += " " + i.ToString();
            }
            data += "\n";
            File.AppendAllText(fileNameTrain, data);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            changeButton(button1, 0);
        }
        private void button2_Click(object sender, EventArgs e)
        {
            changeButton(button2, 1);
        }
        private void button3_Click(object sender, EventArgs e)
        {
            changeButton(button3, 2);
        }
        private void button4_Click(object sender, EventArgs e)
        {
            changeButton(button4, 3);
        }
        private void button5_Click(object sender, EventArgs e)
        {
            changeButton(button5, 4);
        }
        private void button6_Click(object sender, EventArgs e)
        {
            changeButton(button6, 5);
        }
        private void button7_Click(object sender, EventArgs e)
        {
            changeButton(button7, 6);
        }
        private void button8_Click(object sender, EventArgs e)
        {
            changeButton(button8, 7);
        }
        private void button9_Click(object sender, EventArgs e)
        {
            changeButton(button9, 8);
        }
        private void button10_Click(object sender, EventArgs e)
        {
            changeButton(button10, 9);
        }
        private void button11_Click(object sender, EventArgs e)
        {
            changeButton(button11, 10);
        }
        private void button12_Click(object sender, EventArgs e)
        {
            changeButton(button12, 11);
        }
        private void button13_Click(object sender, EventArgs e)
        {
            changeButton(button13, 12);
        }
        private void button14_Click(object sender, EventArgs e)
        {
            changeButton(button14, 13);
        }
        private void button15_Click(object sender, EventArgs e)
        {
            changeButton(button15, 14);
        }

        private void buttonRaspoznat_Click(object sender, EventArgs e)
        {
            net.ForwardPass(net, _inputPixels);
            labelOtvet.Text = net.Fact.ToList().IndexOf(net.Fact.Max()).ToString();

            int predictedDigit = net.Fact.ToList().IndexOf(net.Fact.Max());

            // Также можно добавить подсветку максимальной вероятности
            labelProbability.Text = $"Max: {(net.Fact.Max() * 100).ToString("0.00")}%";
        }
        // сохранить обучающий пример
        private void ButtonSaveTrainSample_Click_1(object sender, EventArgs e)
        {
            SaveTrain(numericUpDownTrue.Value, _inputPixels);

        }
        // сохранить тестовый пример
        private void buttonSaveTestSample_Click(object sender, EventArgs e)
        {
            SaveTest(numericUpDownTrue.Value, _inputPixels);
        }

        private void buttonTrain_Click(object sender, EventArgs e) //обработчик кнопки обучить 
        {
            net.Train(net);
        }

        private void buttonTest_Click(object sender, EventArgs e)
        {
            net.Test(net);
        }
    }
}
