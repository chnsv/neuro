﻿using System;
using System.IO;


namespace OneProject.NeuroNet
{
    class InputLayer
    {
        //поля
        private Random random = new Random();

        private (double[], int)[] trainset; //массив обучающей выборки. 100 изображений, 15 пикселей + желаемый отклик
        private (double[], int)[] testset; // тестовой выборки

        //свойства

        public (double[], int)[] TrainSet => trainset;
        public (double[], int)[] TestSet => testset;

        //конструктор
        public InputLayer(NetworkMode networkMode)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory;
            string[] tmpArrStr;
            string[] tmpStr;

            switch (networkMode)
            {
                case NetworkMode.Train:
                    tmpArrStr = File.ReadAllLines(path + "train.txt"); //считывание из файла обучающей выборки
                    trainset = new (double[], int)[tmpArrStr.Length];
                    double[] inputs;

                    for (int i = 0; i < tmpArrStr.Length; i++)
                    {
                        tmpStr = tmpArrStr[i].Split(' '); // разбиение по разделителю
                        inputs = new double[tmpStr.Length - 1];
                        for (int j = 1; j < tmpStr.Length; j++)
                        {
                            inputs[j - 1] = int.Parse(tmpStr[j], System.Globalization.CultureInfo.InvariantCulture);
                        }
                        trainset[i] = (inputs, int.Parse(tmpStr[0], System.Globalization.CultureInfo.InvariantCulture));

                    }

                    trainset = ShufflingArrayRows(trainset); //перетасовка обучающей выборки методом Фишера-Йетса
                    break;
                case NetworkMode.Test:
                    tmpArrStr = File.ReadAllLines(path + "test.txt");
                    testset = new (double[], int)[tmpArrStr.Length];
                    for (int i = 0; i < tmpArrStr.Length; i++)
                    {
                        tmpStr = tmpArrStr[i].Split(' '); // разбиение по разделителю
                        inputs = new double[tmpStr.Length - 1];
                        for (int j = 1; j < tmpStr.Length; j++)
                        {
                            inputs[j - 1] = int.Parse(tmpStr[j],
                                System.Globalization.CultureInfo.InvariantCulture);
                        }
                        testset[i] = (inputs, int.Parse(tmpStr[0],
                                System.Globalization.CultureInfo.InvariantCulture));
                    }
                    // доделать тестовую, все то же самое только считываем тестовую и испоьлзуем тестовую
                    break;
            }

        }
        public (double[], int)[] ShufflingArrayRows((double[], int)[] arr)
        {
            int j; //номер случайно выбанной строки
            Random random = new Random();

            for (int i = arr.Length - 1; i > 0; i--)
            {
                j = random.Next(i + 1);
                var temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }

            return arr;
        }
    }
}
