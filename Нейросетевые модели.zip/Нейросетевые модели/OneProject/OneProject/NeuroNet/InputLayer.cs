﻿using System;
using System.IO;


namespace OneProject.NeuroNet
{
    class InputLayer
    {
        //поля
        private Random random = new Random();

        private double[,] trainset = new double[100, 16]; //массив обучающей выборки. 100 изображений, 15 пикселей + желаемый отклик
        private double[,] testset = new double[10, 16]; // тестовой выборки

        //свойства
        public double[,] Trainset { get => trainset; }
        public double[,] Testset { get => testset; }

        //конструктор
        public InputLayer(NetworkMode nm)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory;
            string[] tmpStr;
            string[] tmpArrStr;
            double[] tmpArr;
            switch (nm)
            {
                case NetworkMode.Train:
                    tmpArrStr = File.ReadAllLines(path + "train.txt");
                    for (int i = 0; i < tmpArrStr.Length; i++)
                    {
                        string line = tmpArrStr[i];
                        string[] values = line.Split(' '); // Разделяем строку по пробелам

                        // Преобразуем и сохраняем значения
                        for (int j = 0; j < 16; j++)
                        {
                            trainset[i, j] = double.Parse(values[j], System.Globalization.CultureInfo.InvariantCulture);
                        }
                    }
                    //перестановка методом фишера-йетса
                    Shuffling_Array_Rows(trainset);
                    break;
                case NetworkMode.Test:
                    tmpArrStr = File.ReadAllLines(path + "test.txt");
                    for (int i = 0; i < tmpArrStr.Length; i++)
                    {
                        string line = tmpArrStr[i];
                        string[] values = line.Split(' '); // Разделяем строку по пробелам

                        // Преобразуем и сохраняем значения
                        for (int j = 0; j < 16; j++)
                        {
                            testset[i, j] = double.Parse(values[j], System.Globalization.CultureInfo.InvariantCulture);
                        }
                    }
                    Shuffling_Array_Rows(testset);
                    break;
                case NetworkMode.Recogn:
                    break;
            }
        }
        public void Shuffling_Array_Rows(double[,] arr)
        {
            int j; // номер случайно выбранной строки
            Random random = new Random();
            double[] temp = new double[arr.GetLength(1)]; // вспомогательный массив

            for (int n = arr.GetLength(0) - 1; n >= 1; n--) // цикл перебора строк снизу вверх
            {
                j = random.Next(n + 1); // выбор случайной строки из выше расположенных строк

                for (int i = 0; i < arr.GetLength(1); i++) // цикл копирования n-ой строки
                {
                    temp[i] = arr[n, i];
                }
                for (int i = 0; i < arr.GetLength(1); i++) // цикл перестановки двух строк
                {
                    arr[n, i] = arr[j, i]; // заполнение n-ой строки значениями j-ой строки
                    arr[j, i] = temp[i]; // заполнение j-ой строки значенмиями n-ой строки
                }
            }
        }
    }
}
