﻿using System;
using System.Diagnostics.Tracing;

namespace OneProject.NeuroNet
{
    class HiddenLayer : Layer
    {
        public HiddenLayer(int numOfNeurons, int numOfPrevNeurons, NeuronType neuronType, string layerName) :
            base(numOfNeurons, numOfPrevNeurons, neuronType, layerName)
        { }

        public override void Recognize(NetWork net, Layer nextLayer)
        {
            double[] hidden_out = new double[_numOfNeurons];
            for (int i = 0; i < _numOfNeurons; i++)
                hidden_out[i] = Neurons[i].Output;
            nextLayer.Data = hidden_out; //передача выходного сигнала на вход следующего слоя
        }

        /// <summary>
        ///коррекция весов для уменьшения ошибки предскзаания - противоположно гардиенту идеи
        /// </summary>
        /// <param name="Массив локальных градиентов"></param>
        /// <returns></returns>
        public override double[] BackwardPass(double[] gr_sums)
        {
            double[] loc_gr = new double[_numOfPrevNeurons]; //локальный градиент

            for (int i = 0; i < _numOfPrevNeurons; i++)
            {
                double sum = 0;
                for (int j = 0; j < _numOfNeurons; j++)
                {
                    sum += Neurons[j].Weights[i] * Neurons[j].Derivative * gr_sums[j]; //Через градиенты сумму и производную
                }
                loc_gr[i] = sum;
            }

            for (int i = 0; i < _numOfNeurons; i++) // Цикл коррекции синаптических весов
            {
                for (int j = 0; j < 1 + _numOfPrevNeurons; j++)
                {
                    double deltaw;
                    if (j == 0) // если порог
                        deltaw = Momentum * _lastDeltaWeights[i, 0] +
                            LearningRate * Neurons[i].Derivative * gr_sums[i];
                    else
                        deltaw = Momentum * _lastDeltaWeights[i, j] +
                            LearningRate * Neurons[i].Inputs[j - 1] * Neurons[i].Derivative * gr_sums[i];

                    _lastDeltaWeights[i, j] = deltaw;
                    Neurons[i].Weights[j] += deltaw; // коррекция весов
                }
            }

            return loc_gr;
        }
    }
}
