﻿using System;
using System.Linq;
using System.Windows.Forms.DataVisualization.Charting;
using System.Windows.Forms;

namespace OneProject.NeuroNet
{
    class NetWork
    {

        private InputLayer _inputLayer;
        private HiddenLayer _hiddenLayer1 = new HiddenLayer(73, 15, NeuronType.Hidden, nameof(_hiddenLayer1)); // 15 - ВХОДНОЙ, 73 - 30 - СКРЫТЫЙ СЛОЙ, 10 - ВЫХОДНОЙ
        private HiddenLayer _hiddenLayer2 = new HiddenLayer(30, 73, NeuronType.Hidden, nameof(_hiddenLayer2));
        private OutputLayer _outputLayer = new OutputLayer(10, 30, NeuronType.Output, nameof(_outputLayer));

        private double[] _fact = new double[10]; // массив фактического выхода сети
        private double _eErrorAvg; // среднее значение энерги ошибки эпохи обучения

        Form form;
        int _epochK = 0;
        //свойства
        public double[] Fact => _fact;
        public double EErrorAvg { get => _eErrorAvg; set => _eErrorAvg = value; }

        public NetWork(NetworkMode nm)
        {
            _inputLayer = new InputLayer(nm);
        }

        //Прямой проход сигнала по нейросети
        public void ForwardPass(NetWork net, double[] net_input)
        {
            net._hiddenLayer1.Data = net_input;
            net._hiddenLayer1.Recognize(null, net._hiddenLayer2);
            net._hiddenLayer2.Recognize(null, net._outputLayer);
            net._outputLayer.Recognize(net, null);
        }

        // Обучение
        public void Train(NetWork net)
        {
            if (form == null)
            {
                form = CreateChartForm();
                form.Show();
            }

            net._inputLayer = new InputLayer(NetworkMode.Train);
            int epoches = 20; // количество эпох обучения

            double tmpSumError; // Временная переменная суммы ошибок
            double[] errors; //Вектор сигнала ошибки выходного слоя
            double[] tmpGradSums1; //Вектор градиента первого скрытого слоя
            double[] tmpGradSums2; //Вектор градиента второго скрытого слоя

            for (int k = 0; k < epoches; k++)
            {
                _eErrorAvg = 0; // Обнуляем значение в начале эпохи
                for (int i = 0; i < net._inputLayer.TrainSet.Length; i++)
                {
                    //Прямой проход
                    ForwardPass(net, net._inputLayer.TrainSet[i].Item1);

                    //Вычисление ошибки по итерации
                    tmpSumError = 0;
                    errors = new double[net.Fact.Length];
                    for (int x = 0; x < errors.Length; x++)
                    {
                        if (x == net._inputLayer.TrainSet[i].Item2)
                        {
                            errors[x] = 1.0 - net.Fact[x];
                        }
                        else
                        {
                            errors[x] = -net.Fact[x];
                        }

                        //Собираем энергию ошибки
                        tmpSumError += errors[x] * errors[x] / 2.0;
                    }

                    _eErrorAvg += tmpSumError / errors.Length; //Суммарное значение энергии оишбки эпох

                    //Обратный проход и коррекция весов
                    tmpGradSums2 = net._outputLayer.BackwardPass(errors);
                    tmpGradSums1 = net._hiddenLayer2.BackwardPass(tmpGradSums2);
                    net._hiddenLayer1.BackwardPass(tmpGradSums1);
                }

                _eErrorAvg /= net._inputLayer.TrainSet.Length; //Среднее значение энергии ошибки одной эпохи
                UpdateErrorChartAsync(form, _eErrorAvg);
                //Console.WriteLine($"Эпоха {k}, ошибка: {e_error_avg}");
            }

            net._inputLayer = null; //Обнуление входного слоя

            //Сохранение скорректированных весов
            net._hiddenLayer1.WeightsInitialize(MemoryMode.SET, GetWeights(_hiddenLayer1));
            net._hiddenLayer2.WeightsInitialize(MemoryMode.SET, GetWeights(_hiddenLayer2));
            net._outputLayer.WeightsInitialize(MemoryMode.SET, GetWeights(_outputLayer));

        }
        private double[,] GetWeights(Layer layer)
        {
            double[,] weights = new double[layer.Neurons.Length, layer.Neurons[0].Weights.Length];

            for (int i = 0; i < layer.Neurons.Length; i++)
            {
                for (int j = 0; j < layer.Neurons[i].Weights.Length; j++)
                {
                    weights[i, j] = layer.Neurons[i].Weights[j];
                }
            }

            return weights;
        }
        // Тестирование
        public void Test(NetWork net)
        {
            net._inputLayer = new InputLayer(NetworkMode.Test);
            double m = 0;
            for (int i = 0; i < net._inputLayer.TestSet.Length; i++)
            {
                ForwardPass(net, net._inputLayer.TestSet[i].Item1);
                m += (Fact.ToList().IndexOf(Fact.Max()) == net._inputLayer.TestSet[i].Item2) ? 1 : 0;
            }
            MessageBox.Show(
                $"Точность: {m / net._inputLayer.TestSet.Length}",
            "Предсказание",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information,
            MessageBoxDefaultButton.Button1,
            MessageBoxOptions.RightAlign);

        }
        private Form CreateChartForm()
        {
            var errorChartForm = new Form
            {
                Text = "График ошибки",
                Width = 600,
                Height = 400
            };

            Chart errorChart = new Chart
            {
                Dock = DockStyle.Fill
            };
            //errorChart.ChartAreas[0].AxisY.Minimum = 0;
            //errorChart.ChartAreas[0].AxisX.Minimum = 0;

            Series errorSeries = new Series("Ошибка")
            {
                ChartType = SeriesChartType.Line,
                BorderWidth = 2
            };

            errorChart.Series.Add(errorSeries);
            errorChart.ChartAreas.Add(new ChartArea());

            // Добавление Chart на форму
            errorChartForm.Controls.Add(errorChart);

            // Подписка на событие закрытия формы
            errorChartForm.FormClosed += (sender, e) => { form = null; errorChartForm = null; };
            return errorChartForm;
        }
        private void UpdateErrorChartAsync(Form errorChartForm, double error)
        {
            // Вызов метода UpdateChart на форме ErrorChartForm
            errorChartForm.Invoke(new Action(() => UpdateChart(errorChartForm, error)));
        }

        private void UpdateChart(Form form, double error)
        {
            // Получение элемента управления Chart из формы
            Chart errorChart = (Chart)form.Controls[0];

            // Добавление новой точки на график
            errorChart.Series[0].Points.AddXY(_epochK++, error);

            // Обновление графика
            errorChart.Update();
        }

    }
}
