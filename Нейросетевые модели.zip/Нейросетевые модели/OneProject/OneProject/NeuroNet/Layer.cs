﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace OneProject.NeuroNet
{
    abstract class Layer
    {
        //Поля
        protected string _layerName; //Название слоя
        protected int _numOfNeurons;
        protected int _numOfPrevNeurons;
        protected double[,] _lastDeltaWeights;
        protected Neuron[] _neurons;

        protected const double LearningRate = 0.005d;
        protected const double Momentum = 0.04d;

        private string _pathDirWeights;
        private string _pathFileWeights;

        // Свойства
        public Neuron[] Neurons { get => _neurons; set => _neurons = value; }
        public double[] Data
        {
            set
            {
                foreach (Neuron neuron in _neurons)
                {
                    neuron.Inputs = value;
                    neuron.Activator();
                }
            }

        }
        protected Layer(int numOfNeurons, int numOfPrevNeurons, NeuronType neuronType, string layerName)
        {
            _numOfNeurons = numOfNeurons;
            _numOfPrevNeurons = numOfPrevNeurons;
            _layerName = layerName;

            _pathDirWeights = AppDomain.CurrentDomain.BaseDirectory + "memory\\";
            _pathFileWeights = _pathDirWeights + _layerName + "_memory.csv";

            Neurons = new Neuron[_numOfNeurons];
            double[,] Weights;

            if (File.Exists(_pathFileWeights))
                Weights = WeightsInitialize(MemoryMode.GET);
            else
            {
                Directory.CreateDirectory(_pathDirWeights);
                File.Create(_pathFileWeights).Close();
                Weights = WeightsInitialize(MemoryMode.INIT);
            }

            _lastDeltaWeights = new double[_numOfNeurons, _numOfPrevNeurons + 1];
            for (int i = 0; i < _numOfNeurons; i++)
            {
                double[] tmpWeights = new double[_numOfPrevNeurons + 1];
                for (int j = 0; j < _numOfPrevNeurons + 1; j++)
                {
                    tmpWeights[j] = Weights[i, j];
                    Neurons[i] = new Neuron(tmpWeights, neuronType);
                }
            }
        }
        public double[,] WeightsInitialize(MemoryMode mm, double[,] weights = null)
        {
            int i, j;
            char[] delim = new char[] { ';', ' ' }; //Разделитель для слов ; и пробел ' '
            string tmpStr;
            string[] tmpStrWeights;
            if (weights == null)
                weights = new double[_numOfNeurons, _numOfPrevNeurons + 1]; // +1 порого

            switch (mm)
            {
                case MemoryMode.GET:
                    tmpStrWeights = File.ReadAllLines(_pathFileWeights);
                    string[] memory_element;
                    for (i = 0; i < _numOfNeurons; i++)
                    {
                        memory_element = tmpStrWeights[i].Split(delim);
                        for (j = 0; j < _numOfPrevNeurons; j++)
                        {
                            weights[i, j] = double.Parse(memory_element[j].Replace(',', '.'),
                                System.Globalization.CultureInfo.InvariantCulture);
                        }
                    }
                    break;

                case MemoryMode.INIT:
                    Random rand = new Random(); // Инициализация один раз

                    for (i = 0; i < _numOfNeurons; i++)
                    {
                        double sum = 0;
                        double sumSquares = 0;

                        for (j = 0; j < _numOfPrevNeurons + 1; j++)
                        {
                            double randomWeight = (rand.NextDouble() * 2 - 1); // значение в диапазоне (-1; 1)
                            weights[i, j] = randomWeight;
                            sum += weights[i, j];
                            sumSquares += weights[i, j] * weights[i, j];
                        }

                        double mean = sum / (_numOfPrevNeurons + 1);
                        double stdDev = Math.Sqrt(sumSquares / (_numOfPrevNeurons + 1));

                        for (j = 0; j < _numOfPrevNeurons + 1; j++)
                        {
                            double s = (weights[i, j] - mean) / stdDev;
                            weights[i, j] = s; //нормализация весов
                        }
                    }

                    // Сохранение нормализованных весов в файл
                    WeightsInitialize(MemoryMode.SET, weights);
                    break;

                case MemoryMode.SET:
                    List<string> lines = new List<string>();

                    for (i = 0; i < _numOfNeurons; i++)
                    {
                        string line = "";
                        for (j = 0; j < _numOfPrevNeurons + 1; j++)
                        {
                            line += weights[i, j].ToString(System.Globalization.CultureInfo.InvariantCulture) + ";";
                        }
                        lines.Add(line.TrimEnd(';'));
                    }

                    File.WriteAllLines(_pathFileWeights, lines);
                    break;

            }
            return weights;
        }
        //для прямых проходов
        abstract public void Recognize(NetWork net, Layer nextLayer);
        //для обратных проходов
        abstract public double[] BackwardPass(double[] stuff);
    }
}
