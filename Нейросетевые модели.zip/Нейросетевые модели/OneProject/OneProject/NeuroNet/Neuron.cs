﻿using System;
using System.Net.Http.Headers;
using System.Runtime.Serialization.Formatters;
using static System.Math;

namespace OneProject.NeuroNet
{
    class Neuron
    {
        private NeuronType _type; // тип нейрона
        private double[] _weights; // набор весов
        private double[] _inputs; // массив входных данных
        private double _output; // выход нейрона
        private double _derivative; // производная
        // константы для функции активации?
        private double a = 0.01;
        //логистическая функция - написать

        public double[] Weights { get => _weights; set => _weights = value; }
        public double[] Inputs { get => _inputs; set => _inputs = value; }
        public double Output { get => _output; }
        public double Derivative { get => _derivative; }

        public Neuron(double[] weights, NeuronType type) // конструктор
        {
            _weights = weights;
            _type = type;
        }

        // 15 (входных) 73 (первый скрытый слой) 30 (второй скрытый слой) 10 (выходных)
        public void Activator()
        {
            double sum = _weights[0];
            for (int i = 0; i < _inputs.Length; i++)
            {
                sum += _inputs[i] * _weights[i + 1];
            }
            ChooseActivator(sum);
        }
        private void ChooseActivator(double sum)
        {
            switch (_type)
            {
                case NeuronType.Hidden:
                    _output = LeakyReLU(sum);
                    _derivative = LeakyReLU_Derivaсtivator(sum);
                    break;
                case NeuronType.Output:
                    _output = Math.Exp(sum);
                    break;
                default:
                    break;
            }
        }


        private double LeakyReLU(double sum)
        {
            return Max(a * sum, sum);
        }
        private double LeakyReLU_Derivaсtivator(double sum)
        {
            if (sum >= 0)
                return 1;
            else
                return a;
        }

        private double Exp(double sum)
        {
            return 0;
        }
    }
}
