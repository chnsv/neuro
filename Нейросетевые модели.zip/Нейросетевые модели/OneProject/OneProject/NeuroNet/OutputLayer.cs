﻿using System.Xml.Linq;

namespace OneProject.NeuroNet
{
    class OutputLayer : Layer
    {
        public OutputLayer(int numOfNeurons, int numOfPrevNeurons, NeuronType neuronType, string layerName) :
            base(numOfNeurons, numOfPrevNeurons, neuronType, layerName)
        { }
        public override void Recognize(NetWork net, Layer nextLayer)
        {
            double e_sum = 0;
            for (int i = 0; i < Neurons.Length; i++)
                e_sum += Neurons[i].Output;

            for (int i = 0; i < Neurons.Length; i++)
                net.Fact[i] = Neurons[i].Output / e_sum;
        }

        public override double[] BackwardPass(double[] errors)
        {
            double[] loc_gr = new double[_numOfPrevNeurons + 1];
            for (int i = 0; i < _numOfPrevNeurons + 1; i++) // Вычисление градиента
            {
                double sum = 0;
                for (int j = 0; j < _numOfNeurons; j++)
                    sum += Neurons[j].Weights[i] * errors[j];
                loc_gr[i] = sum;
            }

            for (int i = 0; i < _numOfNeurons; i++) // Цикл коррекции синаптических весов
            {
                for (int j = 0; j < _numOfPrevNeurons + 1; j++)
                {
                    double deltaw;
                    if (j == 0) // если порог
                        deltaw = Momentum * _lastDeltaWeights[i, 0] +
                            LearningRate * errors[i];
                    else
                        deltaw = Momentum * _lastDeltaWeights[i, j] +
                            LearningRate * Neurons[i].Inputs[j - 1] * errors[i];

                    _lastDeltaWeights[i, j] = deltaw;
                    Neurons[i].Weights[j] += deltaw; // коррекция весов
                }
            }

            return loc_gr;
        }
    }
}
