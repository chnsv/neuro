﻿
namespace OneProject.NeuroNet
{
    enum NeuronType // тип нейрона
    {
        Hidden,//нейрон скрытого слоя
        Output //нейрон выходного слоя
    }
    enum NetworkMode //режимы работы сети
    {
        Train, //обучение
        Test, //тест
        Recogn //распознование
    }
    enum MemoryMode //режимы работы памяти
    {
        GET, //считывание
        SET, //сохранение 
        INIT //инициализация
    }
}
