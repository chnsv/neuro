﻿using static System.Math;

namespace OneProject.NeuroNet
{
    class Neuron
    {
        private NeuronType _type; // тип нейрона
        private double[] _weights; // массив весов
        private double[] _inputs; // его входы
        private double _output; // его выход
        private double _derivative; // производная функции активации
        // константы для функции активации
        private double a = 0.01; // для leakyRelu

        public double[] Weights { get => _weights; set => _weights = value; }

        public double[] Inputs
        {
            get { return _inputs; }
            set { _inputs = value; }
        }
        public double Output { get => _output; }
        public double Derivative { get => _derivative; }
        public Neuron(double[] inputs, double[] weights, NeuronType type)
        {
            _type = type;
            _weights = weights;
        }

    }
}
