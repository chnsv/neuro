﻿namespace OneProject
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.button15 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.buttonRaspoznat = new System.Windows.Forms.Button();
            this.ButtonSaveTestSample = new System.Windows.Forms.Button();
            this.ButtonSaveTrainSample = new System.Windows.Forms.Button();
            this.numericUpDownTrue = new System.Windows.Forms.NumericUpDown();
            this.labelOtvet = new System.Windows.Forms.Label();
            this.buttonTrain = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.chartEavr = new System.Windows.Forms.DataVisualization.Charting.Chart();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTrue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartEavr)).BeginInit();
            this.SuspendLayout();
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.White;
            this.button15.Location = new System.Drawing.Point(94, 176);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(35, 35);
            this.button15.TabIndex = 0;
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(35, 35);
            this.button1.TabIndex = 1;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(53, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(35, 35);
            this.button2.TabIndex = 2;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(94, 12);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(35, 35);
            this.button3.TabIndex = 5;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.White;
            this.button4.Location = new System.Drawing.Point(12, 53);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(35, 35);
            this.button4.TabIndex = 4;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.White;
            this.button5.Location = new System.Drawing.Point(53, 53);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(35, 35);
            this.button5.TabIndex = 3;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.White;
            this.button6.Location = new System.Drawing.Point(94, 53);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(35, 35);
            this.button6.TabIndex = 8;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.White;
            this.button7.Location = new System.Drawing.Point(12, 94);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(35, 35);
            this.button7.TabIndex = 7;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.White;
            this.button8.Location = new System.Drawing.Point(53, 94);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(35, 35);
            this.button8.TabIndex = 6;
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.White;
            this.button9.Location = new System.Drawing.Point(94, 94);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(35, 35);
            this.button9.TabIndex = 11;
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.White;
            this.button10.Location = new System.Drawing.Point(12, 135);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(35, 35);
            this.button10.TabIndex = 10;
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.White;
            this.button11.Location = new System.Drawing.Point(53, 135);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(35, 35);
            this.button11.TabIndex = 9;
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.White;
            this.button12.Location = new System.Drawing.Point(94, 135);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(35, 35);
            this.button12.TabIndex = 14;
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.White;
            this.button13.Location = new System.Drawing.Point(12, 176);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(35, 35);
            this.button13.TabIndex = 13;
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.White;
            this.button14.Location = new System.Drawing.Point(53, 176);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(35, 35);
            this.button14.TabIndex = 12;
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // buttonRaspoznat
            // 
            this.buttonRaspoznat.Location = new System.Drawing.Point(145, 71);
            this.buttonRaspoznat.Name = "buttonRaspoznat";
            this.buttonRaspoznat.Size = new System.Drawing.Size(107, 23);
            this.buttonRaspoznat.TabIndex = 15;
            this.buttonRaspoznat.Text = "Распознать";
            this.buttonRaspoznat.UseVisualStyleBackColor = true;
            this.buttonRaspoznat.Click += new System.EventHandler(this.buttonRaspoznat_Click);
            // 
            // ButtonSaveTestSample
            // 
            this.ButtonSaveTestSample.Location = new System.Drawing.Point(12, 311);
            this.ButtonSaveTestSample.Name = "ButtonSaveTestSample";
            this.ButtonSaveTestSample.Size = new System.Drawing.Size(129, 66);
            this.ButtonSaveTestSample.TabIndex = 16;
            this.ButtonSaveTestSample.Text = "СОХРАНИТЬ ТЕСТОВЫЙ ПРИМЕР";
            this.ButtonSaveTestSample.UseVisualStyleBackColor = true;
            this.ButtonSaveTestSample.Click += new System.EventHandler(this.buttonSaveTestSample_Click);
            // 
            // ButtonSaveTrainSample
            // 
            this.ButtonSaveTrainSample.Location = new System.Drawing.Point(12, 258);
            this.ButtonSaveTrainSample.Name = "ButtonSaveTrainSample";
            this.ButtonSaveTrainSample.Size = new System.Drawing.Size(129, 47);
            this.ButtonSaveTrainSample.TabIndex = 17;
            this.ButtonSaveTrainSample.Text = "СОХРАНИТЬ ПРИМЕР";
            this.ButtonSaveTrainSample.UseVisualStyleBackColor = true;
            this.ButtonSaveTrainSample.Click += new System.EventHandler(this.buttonSaveTrainSample_Click);
            // 
            // numericUpDownTrue
            // 
            this.numericUpDownTrue.Location = new System.Drawing.Point(53, 230);
            this.numericUpDownTrue.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            0});
            this.numericUpDownTrue.Name = "numericUpDownTrue";
            this.numericUpDownTrue.Size = new System.Drawing.Size(45, 22);
            this.numericUpDownTrue.TabIndex = 18;
            // 
            // labelOtvet
            // 
            this.labelOtvet.AutoSize = true;
            this.labelOtvet.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelOtvet.Location = new System.Drawing.Point(135, 12);
            this.labelOtvet.Name = "labelOtvet";
            this.labelOtvet.Size = new System.Drawing.Size(126, 46);
            this.labelOtvet.TabIndex = 19;
            this.labelOtvet.Text = "label1";
            // 
            // buttonTrain
            // 
            this.buttonTrain.Location = new System.Drawing.Point(143, 100);
            this.buttonTrain.Name = "buttonTrain";
            this.buttonTrain.Size = new System.Drawing.Size(109, 23);
            this.buttonTrain.TabIndex = 20;
            this.buttonTrain.Text = "Обучить";
            this.buttonTrain.UseVisualStyleBackColor = true;
            this.buttonTrain.Click += new System.EventHandler(this.buttonTrain_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(145, 129);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(107, 27);
            this.button16.TabIndex = 21;
            this.button16.Text = "Тестировать";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // chartEavr
            // 
            chartArea1.Name = "ChartArea1";
            this.chartEavr.ChartAreas.Add(chartArea1);
            this.chartEavr.Location = new System.Drawing.Point(290, 25);
            this.chartEavr.Name = "chartEavr";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Name = "Series2";
            this.chartEavr.Series.Add(series1);
            this.chartEavr.Size = new System.Drawing.Size(300, 300);
            this.chartEavr.TabIndex = 22;
            this.chartEavr.Text = "chart1";
            title1.Name = "Title1";
            this.chartEavr.Titles.Add(title1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(751, 396);
            this.Controls.Add(this.chartEavr);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.buttonTrain);
            this.Controls.Add(this.labelOtvet);
            this.Controls.Add(this.numericUpDownTrue);
            this.Controls.Add(this.ButtonSaveTrainSample);
            this.Controls.Add(this.ButtonSaveTestSample);
            this.Controls.Add(this.buttonRaspoznat);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button15);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTrue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartEavr)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button buttonRaspoznat;
        private System.Windows.Forms.Button ButtonSaveTestSample;
        private System.Windows.Forms.Button ButtonSaveTrainSample;
        private System.Windows.Forms.NumericUpDown numericUpDownTrue;
        private System.Windows.Forms.Label labelOtvet;
        private System.Windows.Forms.Button buttonTrain;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartEavr;
    }
}

